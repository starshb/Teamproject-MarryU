package com.example.umarry.auth

data class UserDataModel (
    var uid : String? = null,
    var name : String? = null,
    var nickname : String? = null,
    var age : String? = null,
    var phone : String? = null,
    var birth : String? = null,
    var email : String? = null,
    var password : String? = null

)